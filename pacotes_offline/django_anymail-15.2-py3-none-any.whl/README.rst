Anymail: Django email integration for transactional ESPs
========================================================

..  This README is reused in multiple places:
    * Github: project page, exactly as it appears here
    * Docs: shared-intro section gets included in docs/index.rst
            quickstart section gets included in docs/quickstart.rst
    * PyPI: project page (via pyproject.toml readme; see also
            hatch_build.py which edits in the release version number
            and strips out sponsor-logos that wouldn't render on PyPI)
    You can use docutils 1.0 markup, but *not* any Sphinx additions.
    GitHub rst supports code-block, but *no other* block directives.


.. default-role:: literal


.. _shared-intro:

.. This shared-intro section is also included in docs/index.rst

Anymail lets you send and receive email in Django using your choice
of transactional email service providers (ESPs). It extends the
standard `django.core.mail` with many common ESP-added features, providing
a consistent API that avoids locking your code to one specific ESP
(and making it easier to change ESPs later if needed).

Anymail currently supports these ESPs:

* **Amazon SES**
* **Brevo** (formerly SendinBlue)
* **MailerSend**
* **Mailgun** (Sinch transactional email)
* **Mailjet** (Sinch transactional email)
* **Mailtrap**
* **Mandrill** (MailChimp transactional email)
* **Postal** (self-hosted ESP)
* **Postmark** (ActiveCampaign transactional email)
* **Resend**
* **Scaleway TEM**
* **SendGrid** (Twilio transactional email; no longer tested)
* **SparkPost** (Bird transactional email)
* **Unisender Go**

Anymail includes:

* Integration of each ESP's sending APIs into
  `Django's built-in email <https://docs.djangoproject.com/en/stable/topics/email/>`_
  package, including support for HTML, attachments, extra headers,
  and other standard email features
* Extensions to expose common ESP-added functionality, like tags, metadata,
  and tracking, with code that's portable between ESPs
* Simplified inline images for HTML email
* Full support for Unicode characters everywhere they're allowed in email
  (with workarounds where possible for ESPs that don't quite get it right)
* Normalized sent-message status and tracking notification, by connecting
  your ESP's webhooks to Django signals
* "Batch transactional" sends using your ESP's merge and template features
* Inbound message support, to receive email through your ESP's webhooks,
  with simplified, portable access to attachments and other inbound content

Anymail maintains compatibility with all Django versions that are in mainstream
or extended support, plus (usually) a few older Django versions, and is extensively
tested on all Python versions supported by Django. (Even-older Django versions
may still be covered by an Anymail extended support release; consult the
`changelog <https://anymail.dev/en/stable/changelog/>`_ for details.)

Anymail releases follow `semantic versioning <https://semver.org/>`_.
The package is released under the BSD license.

.. END shared-intro

.. image:: https://github.com/anymail/django-anymail/actions/workflows/test.yml/badge.svg?branch=main
       :target: https://github.com/anymail/django-anymail/actions?query=workflow:test+branch:main
       :alt:    test status in GitHub Actions

.. image:: https://github.com/anymail/django-anymail/actions/workflows/integration-test.yml/badge.svg?branch=main
       :target: https://github.com/anymail/django-anymail/actions?query=workflow:integration-test+branch:main
       :alt:    integration test status in GitHub Actions

.. image:: https://readthedocs.org/projects/anymail/badge/?version=stable
       :target: https://anymail.dev/en/stable/
       :alt:    documentation build status on ReadTheDocs

**Resources**

* Full documentation: https://anymail.dev/en/stable/
* Help and troubleshooting: https://anymail.dev/en/stable/help/
* Package on PyPI: https://pypi.org/project/django-anymail/
* Project on Github: https://github.com/anymail/django-anymail
* Changelog: https://anymail.dev/en/stable/changelog/


Anymail 1-2-3
-------------

.. _quickstart:

.. This quickstart section is also included in docs/quickstart.rst

Here's how to send a message.
This example uses Mailgun, but you can substitute Amazon SES or Mailjet or Postmark
or SparkPost or any other supported ESP where you see "mailgun":

1. Install Anymail from PyPI:

   .. code-block:: console

        $ pip install "django-anymail[mailgun]"

   (The `[mailgun]` part installs any additional packages needed for that ESP.
   Mailgun doesn't have any, but some other ESPs do.)


2. Edit your project's ``settings.py``. In Django 6.1 or later:

   .. code-block:: python

        INSTALLED_APPS = [
            # ...
            "anymail",
            # ...
        ]

        MAILERS = {
            "default": {
                # Change "mailgun" to "amazon_ses" or "mailtrap" or another ESP
                "BACKEND": "anymail.backends.mailgun.EmailBackend",
                "OPTIONS": {
                    # The exact options here depend on your ESP...
                    "api_key": "<your Mailgun key>",
                    "sender_domain": "mg.example.com",  # your Mailgun domain, if needed
                },
            },
        }
        DEFAULT_FROM_EMAIL = "you@example.com"  # if you don't already have this in settings
        SERVER_EMAIL = "your-server@example.com"  # ditto (default from-email for Django errors)

   In Django 6.0 or earlier, replace ``MAILERS`` with ``EMAIL_BACKEND`` and ``ANYMAIL``:

   .. code-block:: python

        # Instead of MAILERS:
        EMAIL_BACKEND = "anymail.backends.mailgun.EmailBackend"
        ANYMAIL = {
            "MAILGUN_API_KEY": "<your Mailgun key>",
            "MAILGUN_SENDER_DOMAIN": 'mg.example.com',
        }


3. Now the regular `Django email functions <https://docs.djangoproject.com/en/stable/topics/email/>`_
   will send through your chosen ESP:

   .. code-block:: python

        from django.core.mail import send_mail

        send_mail("It works!", "This will get sent through Mailgun",
                  "Anymail Sender <from@example.com>", ["to@example.com"])


   You could send an HTML message, complete with an inline image,
   custom tags and metadata:

   .. code-block:: python

        from django.core.mail import EmailMultiAlternatives
        from anymail.message import attach_inline_image_file

        msg = EmailMultiAlternatives(
            subject="Please activate your account",
            body="Click to activate your account: https://example.com/activate",
            from_email="Example <admin@example.com>",
            to=["New User <user1@example.com>", "account.manager@example.com"],
            reply_to=["Helpdesk <support@example.com>"])

        # Include an inline image in the html:
        logo_cid = attach_inline_image_file(msg, "/path/to/logo.jpg")
        html = """<img alt="Logo" src="cid:{logo_cid}">
                  <p>Please <a href="https://example.com/activate">activate</a>
                  your account</p>""".format(logo_cid=logo_cid)
        msg.attach_alternative(html, "text/html")

        # Optional Anymail extensions:
        msg.metadata = {"user_id": "8675309", "experiment_variation": 1}
        msg.tags = ["activation", "onboarding"]
        msg.track_clicks = True

        # Send it:
        msg.send()

.. END quickstart


See the `full documentation <https://anymail.dev/en/stable/>`_
for more features and options, including receiving messages and tracking
sent message status.


Thanks
------

Anymail wouldn't exist without the work of many code
`contributors <https://github.com/anymail/django-anymail/graphs/contributors>`_
and countless others who have taken time to track down bugs, report issues and
participate in discussions. Thank you!

Special thanks to `Anymail's sponsors <https://github.com/sponsors/anymail>`_
for their financial support.

.. BEGIN sponsor-logos

..  These are included only on GitHub. (PyPI's readme renderer doesn't allow
    the raw directive, and figure directives don't work as expected on GitHub.)
    List sponsors horizontally in a single <p>, using &emsp; between them.

.. raw:: html

      <p>
      <img alt src="https://avatars.githubusercontent.com/u/228706481?s=100&amp;v=4" width="50" valign="middle"
        >&nbsp;<a href="https://github.com/mailtrap" rel="nofollow"><strong>Mailtrap</strong></a>
      </p>

      <p>Past sponsors:
      <img alt src="https://avatars.githubusercontent.com/u/98474690?s=60&v=4" width="30" valign="middle"
        >&nbsp;<a href="https://github.com/ecosyste-ms" rel="nofollow">Ecosystems</a>
      </p>

.. END sponsor-logos

Anymail is an independent project not affiliated with any email service
provider. Sponsorship is not meant to imply endorsement.
